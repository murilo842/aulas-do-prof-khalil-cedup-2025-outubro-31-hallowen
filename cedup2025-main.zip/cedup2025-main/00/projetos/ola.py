print("Ola, mundo!") 
