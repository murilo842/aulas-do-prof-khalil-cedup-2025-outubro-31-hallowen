nome = input("Digite seu nome: ") 
print("Ola", nome) 
