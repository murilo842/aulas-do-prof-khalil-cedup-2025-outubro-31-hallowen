nome = input("Seu nome =") 
open("nome.txt", "a").write(nome) 
print("Ola, ", nome) 
